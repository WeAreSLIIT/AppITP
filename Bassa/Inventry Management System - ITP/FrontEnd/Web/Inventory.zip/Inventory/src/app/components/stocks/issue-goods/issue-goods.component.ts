import { StocksService } from '../../../services/stocks.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-issue-goods',
  templateUrl: './issue-goods.component.html',
  styleUrls: ['./issue-goods.component.css']
})
export class IssueGoodsComponent implements OnInit {
  // qty: number;
  // stock: any= {};
  // stocks: Stock[]= [];
  constructor(private stocksService: StocksService) { }

  ngOnInit() {
  }

  // issueGoods( qty,stock){
  //   this.issueGoods(qty,stock).subscribe(data=>{
  //     console.log(data)
  //   });

}
