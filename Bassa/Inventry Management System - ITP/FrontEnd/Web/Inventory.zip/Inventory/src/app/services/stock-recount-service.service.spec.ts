import { TestBed, inject } from '@angular/core/testing';

import { StockRecountServiceService } from './stock-recount-service.service';

describe('StockRecountServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StockRecountServiceService]
    });
  });

  it('should be created', inject([StockRecountServiceService], (service: StockRecountServiceService) => {
    expect(service).toBeTruthy();
  }));
});
