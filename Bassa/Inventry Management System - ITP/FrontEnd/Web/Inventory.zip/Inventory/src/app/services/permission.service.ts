import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class PermissionService {

	constructor(
		private http:Http 
		) { }

	getModules(){
		return this.http.get('http://localhost:5556/api/module').map(res => res.json());
	}

	getModuleById(id){
		return this.http.get('http://localhost:5556/api/module/'+id).map(res => res.json());
	}

	deleteModuleById(id){
		return this.http.delete('http://localhost:5556/api/module/'+id).map(res => res.json());
	}

	addModule( module ){
		return this.http.post('http://localhost:5556/api/module', module).map(res => res.json());
	}

	updateModule(id, module){
		return this.http.put('http://localhost:5556/api/module/'+id,  module).map(res => res.json());
	}

	getPrivileges(){
		return this.http.get('http://localhost:5556/api/privilege').map(res => res.json());
	}

	getPrivilegeById(id){
		return this.http.get('http://localhost:5556/api/privilege/'+id).map(res => res.json());
	}

	deletePrivilegeById(id){
		return this.http.delete('http://localhost:5556/api/privilege/'+id).map(res => res.json());
	}

	addPrivilege( privilege ){
		return this.http.post('http://localhost:5556/api/privilege', privilege).map(res => res.json());
	}

	updatePrivilege(id, privilege){
		return this.http.put('http://localhost:5556/api/privilege/'+id,  privilege).map(res => res.json());
	}
}