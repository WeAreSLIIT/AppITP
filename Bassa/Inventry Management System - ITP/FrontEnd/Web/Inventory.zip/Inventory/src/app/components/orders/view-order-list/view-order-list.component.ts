import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-order-list',
  templateUrl: './view-order-list.component.html',
  styleUrls: ['./view-order-list.component.css']
})
export class ViewOrderListComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}

