import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class OrdersService {

  constructor(
    private http:Http 
  ) { }

  getAllOrders()
  {
  	return this.http.get('http://localhost:5556/api/Order').map(res => res.json());
  }
  
  addOrders(order)
  {
    return this.http.post('http://localhost:5556/api/Order',order).map(res => res.json());
  }

}
