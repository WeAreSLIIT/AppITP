import { Component, OnInit } from '@angular/core';
import { OrdersService} from './../../../services/orders.service';

@Component({
  selector: 'app-request-order',
  templateUrl: './request-order.component.html',
  styleUrls: ['./request-order.component.css']
})
export class RequestOrderComponent implements OnInit {

  publicOrderid : string;
  companyName : string;

  constructor(
    private ordersService : OrdersService
  ) { }

  ngOnInit() {}

  onAddOrder() {
    const order ={
      PublicOrderID: this.publicOrderid,
      OrderDate : 12345678,
      CompanyName :this.companyName

    }
    this.ordersService.addOrders(order).subscribe(data => {
      console.log(data);
  });
}

}
