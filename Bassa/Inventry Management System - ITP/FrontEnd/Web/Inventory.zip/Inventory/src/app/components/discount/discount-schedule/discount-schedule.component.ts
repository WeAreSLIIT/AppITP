import { DiscountScheduleService } from '../../../services/discount-schedule.service';
import { Component, OnInit } from '@angular/core';
import { any } from 'codelyzer/util/function';

@Component({
  selector: 'app-discount-schedule',
  templateUrl: './discount-schedule.component.html',
  styleUrls: ['./discount-schedule.component.css']
})
export class DiscountScheduleComponent implements OnInit {

  discountSchedules: DiscountSchedule[]= [];
  newSchedule: any= {};
  constructor(private discountScheduleService: DiscountScheduleService) { }

  ngOnInit() {
    this.discountScheduleService.getAllDiscountSchedules().subscribe(data =>  {
      this.discountSchedules = data;
      console.log(this.discountSchedules);
    });

  }
  // delete
  onClickDelete(index) {
    this.discountScheduleService.deleteDiscountSchedules(this.discountSchedules[index].DiscountSheduleId).subscribe(data => {
      console.log(data);
    });
    this.discountSchedules.splice(index, 1);
}
// add discount
  saveDiscount(type: DiscountSchedule)
  // tslint:disable-next-line:one-line
  {

        this.discountScheduleService.addDiscountSchedule(type).subscribe(data => {
          console.log(data);
        });
        this.discountSchedules.push(type);
      }

  }

interface DiscountSchedule {
  DiscountSheduleId: number;
  DiscountTypeId: number;
  DiscountType: string;
  DiscountShedulePublicId: string;
  DiscountSheduleItemCode: string;
  OriginalPrice: number;
  PriceWithDiscount: number;
  DiscountSheduleFrom: number;
  DiscountSheduleTo: number;
  DiscountAmount: number;
  Method: number;
  DiscountMethod: number;
}
