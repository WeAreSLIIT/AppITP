import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-gift-voucher',
  templateUrl: './edit-gift-voucher.component.html',
  styleUrls: ['./edit-gift-voucher.component.css']
})
export class EditGiftVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
