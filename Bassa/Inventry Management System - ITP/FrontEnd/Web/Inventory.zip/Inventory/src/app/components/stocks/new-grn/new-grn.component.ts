import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-grn',
  templateUrl: './new-grn.component.html',
  styleUrls: ['./new-grn.component.css']
})
export class NewGrnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
