import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class EmployeeService {

	constructor(
		private http:Http 
		) { }

	getEmployees(){
		return this.http.get('http://localhost:5556/api/employee').map(res => res.json());
	}

	getEmployeeById(id){
		return this.http.get('http://localhost:5556/api/employee/'+id).map(res => res.json());
	}

	deleteEmployeeById(id){
		return this.http.delete('http://localhost:5556/api/employee/'+id).map(res => res.json());
	}

	addEmployee( employee ){
		return this.http.post('http://localhost:5556/api/employee', employee).map(res => res.json());
	}

	updateEmployee(id, employee){
		return this.http.put('http://localhost:5556/api/employee/'+id, employee).map(res => res.json());
	}
}
