import { Component, OnInit } from '@angular/core';
import {SuppliersService} from './../../../services/suppliers.service';

@Component({
  selector: 'app-view-supplier',
  templateUrl: './view-supplier.component.html',
  styleUrls: ['./view-supplier.component.css']
})
export class ViewSupplierComponent implements OnInit {

  suppliers : supplier[];
  constructor(
    private suppliersService:SuppliersService
  ) { }

  ngOnInit() {
    this.suppliersService.getSuppliers().subscribe(data => {
      this.suppliers = data;
    });
  }

}

interface supplier {


    Brand: string;
    ProductID: string;
    SupplierID: number;
    PublicSupplierID: string;
    FirstName: string;
    LastName: string;
    tel:number;
    email:string;
    suppliedtype:string;
    companyName:string;
    companyAddress:string;
    companyPhone:string;
    AddedDate:number;
 
}