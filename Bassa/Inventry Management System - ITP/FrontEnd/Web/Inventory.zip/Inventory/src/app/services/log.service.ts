import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class LogService {

	constructor(
		private http:Http 
		) { }

	getLogs(){
		return this.http.get('http://localhost:5556/api/log').map(res => res.json());
	}

	getLogById(id){
		return this.http.get('http://localhost:5556/api/log/'+id).map(res => res.json());
	}

	deleteLogById(id){
		return this.http.delete('http://localhost:5556/api/log/'+id).map(res => res.json());
	}

	addLog( log ){
		return this.http.post('http://localhost:5556/api/log', log).map(res => res.json());
	}

	updateLog(id, log){
		return this.http.put('http://localhost:5556/api/log/'+id,  log).map(res => res.json());
	}
}