import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()
export class CustomerService {

  constructor(private http:Http) { }
  getAllCustomers(){
    return this.http.get('http://localhost:5556/api/Customers').map(res => res.json());
  }

  getCustomer(customerId){
    return this.http.get('http://localhost:5556/api/Customers/'+customerId).map(res => res.json());
  }

  addCustomer(customer){
    return this.http.post('http://localhost:5556/api/Customers',customer).map(res => res.json());
  }

  UpdateCustomer(customerId,customer){
    return this.http.put('http://localhost:5556/api/Customers/'+customerId,customer).map(res => res.json());
  }

  DeleteCustomer(customerId){
    return this.http.delete('http://localhost:5556/api/Customers/'+customerId).map(res => res.json());
  }

  GetCustomerCredit(customerId){
    return this.http.get('http://localhost:5556/api/Credits/'+customerId).map(res=>res.json());
  }


}
