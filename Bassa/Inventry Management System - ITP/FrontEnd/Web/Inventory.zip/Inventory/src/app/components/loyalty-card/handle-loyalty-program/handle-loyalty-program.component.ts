import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-handle-loyalty-program',
  templateUrl: './handle-loyalty-program.component.html',
  styleUrls: ['./handle-loyalty-program.component.css']
})
export class HandleLoyaltyProgramComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
