import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-gift-voucher',
  templateUrl: './view-gift-voucher.component.html',
  styleUrls: ['./view-gift-voucher.component.css']
})
export class ViewGiftVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
