import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-redeem-gift-voucher',
  templateUrl: './redeem-gift-voucher.component.html',
  styleUrls: ['./redeem-gift-voucher.component.css']
})
export class RedeemGiftVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
