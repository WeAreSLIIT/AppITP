import { Component, OnInit } from '@angular/core';
import { LoyaltyService } from './../../../services/loyalty.service';

@Component({
  selector: 'app-add-loyalty-program',
  templateUrl: './add-loyalty-program.component.html',
  styleUrls: ['./add-loyalty-program.component.css']
})
export class AddLoyaltyProgramComponent implements OnInit {

  AddLPName : string;
  AddProductInclusion : String;
  AddCreatedDate: number;
  AddDescription : string;


  constructor(private loyaltyService : LoyaltyService) { }

  ngOnInit() {}

  onaddLoyaltyProgram(){
    const loyaltyprogram={
      LoyaltyProgramName :this.AddLPName,
      ProductInclusion : this.AddProductInclusion,
      CreatedDate :this.AddCreatedDate,
      Description : this.AddDescription
      
    }
    this.loyaltyService.addLoyaltyProgram(loyaltyprogram).subscribe(data=>{console.log(data)});
  }

}
interface loyaltyprogram {
  LoyaltyProgramName : string;
  ProductInclusion : string;
  CreatedDate : number;
  Description : string;
  
}
