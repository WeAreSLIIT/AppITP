import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()
export class LoyaltyService {

  constructor(private http:Http) { }

  getAllloyaltyprograms(){
    return this.http.get('http://localhost:5556/api/LoyaltyPrograms').map(res => res.json());
  }

  getloyaltyprogram(loyaltyprogramId){
    return this.http.get('http://localhost:5556/api/LoyaltyPrograms/'+loyaltyprogramId).map(res => res.json());
  }

  addLoyaltyProgram(loyaltyprogram){
    return this.http.post('http://localhost:5556/api/LoyaltyPrograms',loyaltyprogram).map(res => res.json());
  }

  UpdateCustomer(loyaltyprogramId,loyaltyprogram){
    return this.http.put('http://localhost:5556/api/LoyaltyPrograms/'+loyaltyprogramId,loyaltyprogram).map(res => res.json());
  }

  DeleteCustomer(loyaltyprogramId){
    return this.http.delete('http://localhost:5556/api/LoyaltyPrograms/'+loyaltyprogramId).map(res => res.json());
  }

}
