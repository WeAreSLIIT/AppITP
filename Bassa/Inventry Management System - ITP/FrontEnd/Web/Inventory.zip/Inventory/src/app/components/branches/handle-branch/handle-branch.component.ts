import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-handle-branch',
  templateUrl: './handle-branch.component.html',
  styleUrls: ['./handle-branch.component.css']
})
export class HandleBranchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
