import { Component, OnInit } from '@angular/core';
import { CategoriesService } from './../../../services/categories.service';
import { ProductsService } from './../../../services/products.service';

@Component({
  selector: 'app-handle-product',
  templateUrl: './handle-product.component.html',
  styleUrls: ['./handle-product.component.css']
})
export class HandleProductComponent implements OnInit {

  selectedCategory : Number;
  selectedSubCategory : Number;
  updateProductPublicId : string;
  updateProductName : string;
  updateBrand :string;
  updateCost : number;
  updateNotifyDay : number;
  updatePrice : number;
  updatePriceType : number;
  updateUnit : number;
  updateNumberOfUnits : number;
  removeProductId : string;
  categories : category[];
  subCategories : subCategory[];

  constructor(
    private categoryService : CategoriesService,
    private productService : ProductsService
  ) { }

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(data =>{
      this.categories = data;
    });
  }

  ongetSubCategory() {
    this.categoryService.getSubCategory(this.selectedCategory).subscribe(data =>{
      this.subCategories = data;
    });
  }

  onupdateProduct() {
    const product = {
     SubCategoryId : this.selectedSubCategory,
     ProductPublicId: this.updateProductPublicId,
     ProductName: this.updateProductName,
     ProductBrand: this.updateBrand,
     Cost: this.updateCost,
     NotifyDay: this.updateNotifyDay,
     Price: this.updatePrice,
     PriceType: this.updatePriceType,
     NumberOfUnits: this.updateNumberOfUnits,
     Unit: this.updateUnit,
    }
    this.productService.updateProduct(product).subscribe(data =>{
      console.log(data);
    });
  }

  onremoveProduct() {
    this.productService.removeProduct(this.removeProductId).subscribe(data =>{
      console.log(data);
    });
  }
}

interface category {
  CategoryId: number;
  CategoryName: string;
}

interface subCategory {
  SubCategoryId: number;
  SubCategoryName: string;
  CategoryId: number;
}

interface product {
  ProductId: number;
  ProductPublicId: string;
  ProductName: string;
  ProductBrand: string;
  Cost: number;
  NotifyDay: number;
  Price: number;
  PriceType: number;
  NumberOfUnits: number;
  Unit: number;
  SubCategoryId: number;
}
