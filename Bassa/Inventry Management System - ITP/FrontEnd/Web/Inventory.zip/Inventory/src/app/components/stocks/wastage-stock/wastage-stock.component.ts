import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wastage-stock',
  templateUrl: './wastage-stock.component.html',
  styleUrls: ['./wastage-stock.component.css']
})
export class WastageStockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
