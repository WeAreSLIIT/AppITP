import { Component, OnInit } from '@angular/core';
import { ProductsService} from './../../../services/products.service';

@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.css']
})
export class ViewProductComponent implements OnInit {

  searchType : number;
  productSearch : string;
  products : product[];
  product : product;
  
  constructor(
  	private productsService : ProductsService
  	) { }

  ngOnInit() {
  	this.productsService.getAllProducts().subscribe(data =>{
      this.products = data;
    });
  }

  ongetProduct()
  {
    console.log(this.searchType);
    console.log(this.productSearch);

    // if(this.searchType == 1)
    // {
    //   this.productsService.getProductById(this.productSearch).subscribe(data =>{
    //     this.product = data;
    //   });
    // }
    // else if(this.searchType == 2)
    // {
    //   this.productsService.getProductByName(this.productSearch).subscribe(data =>{
    //     this.product = data;
    //   });
    // }
    // else
    // {
    //   console.log("error");
    // }
  }
}

interface product {
  ProductId: number;
  ProductPublicId: string;
  Barcode: string;
  ProductName: string;
  ProductBrand: string;
  Cost: number;
  NotifyDay: number;
  Price: number;
  PriceType: number;
  NumberOfUnits: number;
  Unit: number;
  RackId: number;
  Rack: string;
  SubCategoryId: number;
  SubCategory: string;
}
