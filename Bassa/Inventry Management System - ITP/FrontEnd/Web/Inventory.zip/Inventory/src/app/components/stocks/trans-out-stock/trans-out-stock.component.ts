import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trans-out-stock',
  templateUrl: './trans-out-stock.component.html',
  styleUrls: ['./trans-out-stock.component.css']
})
export class TransOutStockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
