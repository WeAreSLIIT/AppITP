import { Component, OnInit } from '@angular/core';
import { CustomerService } from './../../../services/customer.service';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  

  GetCustomerPublicID : string;
  GetFirstName : String;
  GetLastName : string;
  GetAddress : string;
  GetEmail :string;
  GetCity : string;
  GetDOB : Date;
  GetPhone :number;
 
  customers : customer;

  constructor(private customerService : CustomerService) { }

  ngOnInit() {
    this.customerService.getCustomer(2).subscribe(data =>{
              this.customers = data;
    });
  }

  onUpdateCustomer(){
    const customer={
      /*CustomerPublicID :this.GetCustomerPublicID,
      FirstName : this.GetFirstName,
      LastName : this.GetLastName,
      Address : this.GetAddress,
      Email : this.GetEmail,
      City : this.GetCity,
      DOB: this.GetDOB,*/
      Phone :this.GetPhone
      
    }
    this.customerService.UpdateCustomer(2,customer).subscribe(data=>{console.log(data)});
  }
}
interface customer {
  CustomerPublicID : string;
  FirstName : String;
  LastName : string;
  Address : string;
  Email :string;
  City : string;
  DOB : Date;
  Phone :number;


}