import { Component, OnInit } from '@angular/core';
import { CategoriesService } from './../../../services/categories.service';
import { ProductsService } from './../../../services/products.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  selectedCategory : Number;
  selectedSubCategory : Number;
  addProductPublicId : string;
  addBarcode : string;
  addProductName : string;
  addBrand :string;
  addCost : number;
  addNotifyDay : number;
  addPrice : number;
  addPriceType : number;
  addUnit : number;
  addNumberOfUnits : number;
  categories : category[];
  subCategories : subCategory[];

  constructor(
    private categoryService : CategoriesService,
    private productService : ProductsService
  ) { }

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(data =>{
      this.categories = data;
    });
  }

  ongetSubCategory() {
    this.categoryService.getSubCategory(this.selectedCategory).subscribe(data =>{
      this.subCategories = data;
    });
  }

  onaddProduct() {
    const product = {
     SubCategoryId : this.selectedSubCategory,
     ProductPublicId: this.addProductPublicId,
     Barcode: this.addBarcode,
     ProductName: this.addProductName,
     ProductBrand: this.addBrand,
     Cost: this.addCost,
     NotifyDay: this.addNotifyDay,
     Price: this.addPrice,
     PriceType: this.addPriceType,
     NumberOfUnits: this.addNumberOfUnits,
     Unit: this.addUnit,
     RackId: null
    }
    this.productService.addProduct(product).subscribe(data =>{
      console.log(data);
    });
  }

}

interface category {
  CategoryId: number;
  CategoryName: string;
}

interface subCategory {
  SubCategoryId: number;
  SubCategoryName: string;
  CategoryId: number;
}

interface product {
  ProductId: number;
  ProductPublicId: string;
  Barcode: string;
  ProductName: string;
  ProductBrand: string;
  Cost: number;
  NotifyDay: number;
  Price: number;
  PriceType: number;
  NumberOfUnits: number;
  Unit: number;
  RackId: number;
  SubCategoryId: number;
}
