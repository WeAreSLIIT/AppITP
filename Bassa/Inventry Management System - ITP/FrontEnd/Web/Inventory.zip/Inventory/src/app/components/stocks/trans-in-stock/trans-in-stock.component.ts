import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trans-in-stock',
  templateUrl: './trans-in-stock.component.html',
  styleUrls: ['./trans-in-stock.component.css']
})
export class TransInStockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
