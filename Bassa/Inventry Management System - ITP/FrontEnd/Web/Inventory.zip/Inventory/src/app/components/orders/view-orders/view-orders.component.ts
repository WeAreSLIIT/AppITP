import { Component, OnInit } from '@angular/core';
import { OrdersService} from './../../../services/orders.service';

@Component({
  selector: 'app-view-orders',
  templateUrl: './view-orders.component.html',
  styleUrls: ['./view-orders.component.css']
})
export class ViewOrdersComponent implements OnInit {

  orders : order[];  

  constructor(
    private ordersService : OrdersService
  ) { }

  ngOnInit() {
    this.ordersService.getAllOrders().subscribe(data => {
      this.orders = data;
    });
  }

}

interface order{
  OrderID : number;
  PublicOrderID : string;
  OrderDate : Date;
  CompanyName : string;
}