import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout-supplier-payment',
  templateUrl: './checkout-supplier-payment.component.html',
  styleUrls: ['./checkout-supplier-payment.component.css']
})
export class CheckoutSupplierPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
