import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class SuppliersService {

  constructor(
    private http:Http
  ) { }

  addSupplier(supplier)
  {
    return this.http.post('http://localhost:5556/api/supplier',supplier).map(res => res.json());
  }
  getSuppliers(){
    return this.http.get('http://localhost:5556/api/supplier').map(res => res.json());
  
  }
  getSupplierById(id){
    return this.http.get('http://localhost:5556/api/supplier/'+id).map(res => res.json());
  
  }
  removeSupplierById(id){
    return this.http.delete('http://localhost:5556/api/supplier/'+id).map(res => res.json());
  
  }
  updateSupplier(id, supplier){
    return this.http.put('http://localhost:5556/api/supplier/'+id,supplier).map(res => res.json());
  
  }
}
  