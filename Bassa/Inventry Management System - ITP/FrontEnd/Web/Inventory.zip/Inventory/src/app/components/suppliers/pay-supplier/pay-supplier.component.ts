import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-supplier',
  templateUrl: './pay-supplier.component.html',
  styleUrls: ['./pay-supplier.component.css']
})
export class PaySupplierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
