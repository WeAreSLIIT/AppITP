import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class BranchService {

	constructor(
		private http:Http 
		) { }

	getBranches(){
		return this.http.get('http://localhost:5556/api/branch').map(res => res.json());
	}

	getBranchById(id){
		return this.http.get('http://localhost:5556/api/branch/'+id).map(res => res.json());
	}

	deleteBranchById(id){
		return this.http.delete('http://localhost:5556/api/branch/'+id).map(res => res.json());
	}

	addBranch( branch ){
		return this.http.post('http://localhost:5556/api/branch', branch).map(res => res.json());
	}

	updateBranch(id, branch){
		return this.http.put('http://localhost:5556/api/branch/'+id, branch).map(res => res.json());
	}
}