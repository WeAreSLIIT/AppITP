import { Component, OnInit } from '@angular/core';
import { SectionsService } from './../../../services/sections.service';

@Component({
  selector: 'app-handle-section',
  templateUrl: './handle-section.component.html',
  styleUrls: ['./handle-section.component.css']
})
export class HandleSectionComponent implements OnInit {

  addSectionName : string;
  selectedSectionId : number;
  addRackName : string;
  removeSectionId : number;
  selectedRackForSec : number;
  removeRackId : number;
  racks : rack[];
  sections : section[];

  constructor(
    private sectionService : SectionsService
  ) { }

  ngOnInit() {
    this.sectionService.getAllSections().subscribe(data =>{
      this.sections = data;
    });
  }

  onaddSection() {
    const section = {
      SectionName: this.addSectionName
    }
    this.sectionService.addSections(section).subscribe(data =>{
      console.log(data);
    });
  }

  onaddRack() {
    const rack = {
      RackName: this.addRackName,
      SectionId : this.selectedSectionId
    }
    this.sectionService.addRacks(rack).subscribe(data =>{
     console.log(data);
    });
  }

  onremoveSection() {
    this.sectionService.removeSections(this.removeSectionId).subscribe(data =>{
      console.log(data);
    });
  }

  ongetRack() {
    this.sectionService.getRack(this.selectedRackForSec).subscribe(data =>{
      this.racks = data;
    });
  }

  onremoveRack() {
    this.sectionService.removeRacks(this.removeRackId).subscribe(data =>{
      console.log(data);
    });
  }
    
}

interface section {
  SectionId: number;
  SectionName: string;
}

interface rack {
  RackId: number;
  RackName: string;
  SectionId: number;
}