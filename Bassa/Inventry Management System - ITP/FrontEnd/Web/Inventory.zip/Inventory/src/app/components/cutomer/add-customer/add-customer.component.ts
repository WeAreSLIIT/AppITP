import { Component, OnInit } from '@angular/core';
import { CustomerService } from './../../../services/customer.service'

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  AddCustomerPublicID : string;
  AddFirstName : String;
  AddLastName : string;
  AddAddress : string;
  AddEmail :string;
  AddCity : string;
  AddDOB : Date;
  AddPhone :number;
  AddPassword:string;

  SecurityQuestion:string;
  Answer:string;

  constructor(private customerService : CustomerService) { }

  ngOnInit() {}

  onaddCustomer(){
    const customer={
      CustomerPublicID :this.AddCustomerPublicID,
      FirstName : this.AddFirstName,
      LastName : this.AddLastName,
      Address : this.AddAddress,
      Email : this.AddEmail,
      City : this.AddCity,
      DOB: this.AddDOB,
      Phone :this.AddPhone, 
      Password :this.AddPassword
    }
    this.customerService.addCustomer(customer).subscribe(data=>{console.log(data)});
  }
}
interface customer {
  CustomerPublicID : string;
  FirstName : String;
  LastName : string;
  Address : string;
  Email :string;
  City : string;
  DOB : Date;
  Phone :number;
  Password:string;
}







