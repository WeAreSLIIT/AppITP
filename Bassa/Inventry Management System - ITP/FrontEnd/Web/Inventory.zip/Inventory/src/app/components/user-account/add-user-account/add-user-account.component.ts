import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-user-account',
  templateUrl: './add-user-account.component.html',
  styleUrls: ['./add-user-account.component.css']
})
export class AddUserAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
