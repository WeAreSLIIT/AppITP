import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recount-transaction',
  templateUrl: './recount-transaction.component.html',
  styleUrls: ['./recount-transaction.component.css']
})
export class RecountTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
