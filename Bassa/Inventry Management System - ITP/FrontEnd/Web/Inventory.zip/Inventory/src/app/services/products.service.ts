import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()
export class ProductsService {

  constructor(
  	private http:Http 
  	) { }

  getAllProducts()
  {
  	return this.http.get('http://localhost:5556/api/Product').map(res => res.json());
  }

  addProductsToRacks(rack,productId)
  {
    return this.http.post('http://localhost:5556/api/Product/'+productId+'/InsertRack',rack).map(res => res.json());
  }

  updateProductInRack(rack,productId)
  {
    return this.http.put('http://localhost:5556/api/Product/'+productId,rack).map(res => res.json());
  }

  removeProductInRack(productId)
  {
    return this.http.delete('http://localhost:5556/api/Product/'+productId+'/RemoveProductInRack').map(res => res.json());
  }

  addProduct(product)
  {
    return this.http.post('http://localhost:5556/api/Product',product).map(res => res.json());
  }

  updateProduct(product)
  {
    return this.http.put('http://localhost:5556/api/Product',product).map(res => res.json());
  }

  removeProduct(productId)
  {
    return this.http.delete('http://localhost:5556/api/Product/'+productId+'/RemoveProduct').map(res => res.json());
  }

  getProductById(productId)
  {
    return this.http.get('http://localhost:5556/api/Product/'+productId+'/GetProductById').map(res => res.json());
  }

  getProductByName(productId)
  {
    return this.http.get('http://localhost:5556/api/Product/'+productId+'/GetProductByName').map(res => res.json());
  }
}
