import { TestBed, inject } from '@angular/core/testing';

import { ReturnToSupplierServiceService } from './return-to-supplier-service.service';

describe('ReturnToSupplierServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReturnToSupplierServiceService]
    });
  });

  it('should be created', inject([ReturnToSupplierServiceService], (service: ReturnToSupplierServiceService) => {
    expect(service).toBeTruthy();
  }));
});
