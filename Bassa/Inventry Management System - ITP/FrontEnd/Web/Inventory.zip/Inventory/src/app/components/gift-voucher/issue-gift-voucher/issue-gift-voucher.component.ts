import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-issue-gift-voucher',
  templateUrl: './issue-gift-voucher.component.html',
  styleUrls: ['./issue-gift-voucher.component.css']
})
export class IssueGiftVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
