import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-handle-user-account',
  templateUrl: './handle-user-account.component.html',
  styleUrls: ['./handle-user-account.component.css']
})
export class HandleUserAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
