import { Component, OnInit } from '@angular/core';
import {SuppliersService} from './../../../services/suppliers.service';

@Component({
  selector: 'app-add-supplier',
  templateUrl: './add-supplier.component.html',
  styleUrls: ['./add-supplier.component.css']
})
export class AddSupplierComponent implements OnInit {
  publicsupplierid: string;
  firstname: string;
  lastname: string;
  Tel: number;
  Email: string;
  SuppliedType: string
  ComapanyName: string;
  CompanyAddress: string;
  CompanyPhone: number;
  addeddate: number;

  constructor(
    private suppliersService:SuppliersService
  ) { }

  ngOnInit() {
  }

  onAddSupplier() {
    const supplier ={
      PublicSupplierID: this.publicsupplierid,
      FirstName:this.firstname,
      LastName:this.lastname,
      tel:this.Tel,
      email:this.Email,
      suppliedtype:this.SuppliedType,
      companyName:this.ComapanyName,
      companyAddress:this.CompanyAddress,
      companyPhone:this.CompanyPhone,
      AddedDate : 112334

    }
    this.suppliersService.addSupplier(supplier).subscribe(data => {
      console.log(data);
  });

  console.log("RRfdsf");
  }

}
