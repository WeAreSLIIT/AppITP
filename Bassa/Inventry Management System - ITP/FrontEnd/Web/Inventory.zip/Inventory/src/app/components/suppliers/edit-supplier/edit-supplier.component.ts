import { Component, OnInit } from '@angular/core';
import {SuppliersService} from './../../../services/suppliers.service';


@Component({
  selector: 'app-edit-supplier',
  templateUrl: './edit-supplier.component.html',
  styleUrls: ['./edit-supplier.component.css']
})
export class EditSupplierComponent implements OnInit {
  publicsupplierid: string;
  firstname: string;
  lastname: string;
  Tel: number;
  Email: string;
  SuppliedType: string
  ComapanyName: string;
  CompanyAddress: string;
  CompanyPhone: number;
  addeddate: number;

  constructor(private suppliersService:SuppliersService) { }

  ngOnInit() {
  }
onEditSupplier() {
    const supplier ={
      PublicSupplierID: this.publicsupplierid,
      FirstName:this.firstname,
      LastName:this.lastname,
      tel:this.Tel,
      email:this.Email,
      suppliedtype:this.SuppliedType,
      companyName:this.ComapanyName,
      companyAddress:this.CompanyAddress,
      companyPhone:this.CompanyPhone,
      AddedDate : 112334

    }
    this.suppliersService.updateSupplier(this.publicsupplierid,supplier).subscribe(data => {
      console.log(data);
  });

  }
  onremoveProduct() {
    this.suppliersService.removeSupplierById(this.publicsupplierid).subscribe(data =>{
      console.log(data);
    });
  }

}
