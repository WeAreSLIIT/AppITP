import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class UserService {

	constructor(
		private http:Http 
		) { }

	getUserAccounts(){
		return this.http.get('http://localhost:5556/api/userAccount').map(res => res.json());
	}

	getUserAccountById(id){
		return this.http.get('http://localhost:5556/api/userAccount/'+id).map(res => res.json());
	}

	deleteUserAccountById(id){
		return this.http.delete('http://localhost:5556/api/userAccount/'+id).map(res => res.json());
	}

	addUserAccount( userAccount ){
		return this.http.post('http://localhost:5556/api/userAccount', userAccount).map(res => res.json());
	}

	updateUserAccount(id, userAccount){
		return this.http.put('http://localhost:5556/api/userAccount/'+id,  userAccount).map(res => res.json());
	}

	getUserRoles(){
		return this.http.get('http://localhost:5556/api/userRoles').map(res => res.json());
	}

	getUserRoleById(id){
		return this.http.get('http://localhost:5556/api/userRoles/'+id).map(res => res.json());
	}

	deleteUserRoleById(id){
		return this.http.delete('http://localhost:5556/api/userRoles/'+id).map(res => res.json());
	}

	addUserRole( userRoles ){
		return this.http.post('http://localhost:5556/api/userRoles', userRoles).map(res => res.json());
	}

	updateUserRole(id, userRoles){
		return this.http.put('http://localhost:5556/api/userRoles/'+id,  userRoles).map(res => res.json());
	}
}