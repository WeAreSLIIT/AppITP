import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './../../../services/employee.service';

@Component({
  selector: 'app-handle-employees',
  templateUrl: './handle-employees.component.html',
  styleUrls: ['./handle-employees.component.css']
})
export class HandleEmployeesComponent implements OnInit {

	employees : employee[];
  constructor(
  	private employeeService:EmployeeService
  	) { }

  ngOnInit() {
  	this.employeeService.getEmployees().subscribe(data=>{
  		this.employees = data;
  		console.log(this.employees);
  	});
  }

  getGender(genderId){
  	return (genderId==1)? "Male" : "Female";
  }

  onDeleteEmployee(index) {
    this.employeeService.deleteEmployeeById(this.employees[index].PersonID).subscribe(data =>{
      console.log(data);
      this.employees.splice(index,1);
    });
  }

}


interface employee {
	EmployeeID: number;
    EmployeeName: string;
    JobTitle: string;
    Suspend: boolean;
    PersonID: number;
    FirstName: string;
    LastName: string;
    InitialName: string;
    Street: string;
    Town: string;
    City: string;
    Province: string;
    NIC: string;
    Email: string;
    Gender: number;
}