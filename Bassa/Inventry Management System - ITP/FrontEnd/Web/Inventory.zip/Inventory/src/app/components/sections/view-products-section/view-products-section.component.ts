import { Component, OnInit } from '@angular/core';
import { ProductsService} from './../../../services/products.service';

@Component({
  selector: 'app-view-products-section',
  templateUrl: './view-products-section.component.html',
  styleUrls: ['./view-products-section.component.css']
})
export class ViewProductsSectionComponent implements OnInit {

  searchType : number;
  productSearch : string;
  products : product[];
  product : product;
  
  constructor(
  	private productsService : ProductsService
  	) { }

  ngOnInit() {
  	this.productsService.getAllProducts().subscribe(data =>{
      this.products = data;
  	});
  }

  ongetProduct()
  {
    console.log(this.searchType);
    console.log(this.productSearch);

    // this.productsService.getProductById(this.productSearch).subscribe(data =>{
    //   this.products = data;
    // });
    
    // if(this.searchType == 1)
    // {
    //   this.productsService.getProductById(this.productSearch).subscribe(data =>{
    //     this.products = data;
    //   });
    // }
    // else if(this.searchType == 2)
    // {
    //   this.productsService.getProductByName(this.productSearch).subscribe(data =>{
    //     this.products = data;
    //   });
    // }
    // else
    // {
    //   console.log("error");
    // }
  }

}

interface product {
  ProductId: number;
  ProductPublicId: string;
  ProductName: string;
  ProductBrand: string;
  Price: number;
  RackId: number;
  Rack: string;
  SubCategoryId: number;
  SubCategory: string;
}