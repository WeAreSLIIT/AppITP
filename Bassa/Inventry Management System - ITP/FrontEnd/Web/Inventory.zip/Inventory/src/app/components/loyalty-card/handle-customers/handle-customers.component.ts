
import { Component, OnInit } from '@angular/core';
import { CustomerService } from './../../../services/customer.service';

@Component({
  selector: 'app-handle-customers',
  templateUrl: './handle-customers.component.html',
  styleUrls: ['./handle-customers.component.css']
})
export class HandleCustomersComponent implements OnInit {

  customers : customer[];
  constructor( private customerService:CustomerService) {

   }

  ngOnInit() {
    this.customerService.getAllCustomers().subscribe(data=>{
      this.customers = data;
      console.log(this.customers);
    });
  }

  onClickDelete(CustomerID){
         this.customerService.DeleteCustomer(this.customers[CustomerID].CustomerID).subscribe(data=>{
          console.log(data)
          this.customers.splice(CustomerID,1);
        });
  }

  }

interface customer {
  
    CustomerID: number;
    CustomerPublicID: string;
    FirstName: string;
    LastName : string;
    Address : string;
    Email : string;
    City: string;
    DOB : number;
    Phone : number;
    Password: string;
    CreditLimit :number;
    CreditAmount :number;
    

}
