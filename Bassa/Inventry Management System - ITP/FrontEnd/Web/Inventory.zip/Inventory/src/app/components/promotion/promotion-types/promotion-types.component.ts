import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promotion-types',
  templateUrl: './promotion-types.component.html',
  styleUrls: ['./promotion-types.component.css']
})
export class PromotionTypesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
