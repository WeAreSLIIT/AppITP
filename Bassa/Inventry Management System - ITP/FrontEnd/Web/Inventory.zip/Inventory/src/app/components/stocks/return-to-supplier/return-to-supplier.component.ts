import { ReturnToSupplierServiceService } from '../../../services/return-to-supplier-service.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-to-supplier',
  templateUrl: './return-to-supplier.component.html',
  styleUrls: ['./return-to-supplier.component.css']
})
export class ReturnToSupplierComponent implements OnInit {
  returns: Return[];
    stock: any= {};
   returnStocks: Return[]= [];
  constructor(private returnToSupplierServiceService: ReturnToSupplierServiceService) { }

    ngOnInit() {
    this.returnToSupplierServiceService.getReturnDetails().subscribe(data => {
      this.returns = data;
      console.log(this.returns);
    });
    }
    onClickDelete(index)  {
      this.returnToSupplierServiceService.deleteReturns(this.returns[index].ReturnStockID).subscribe(data => {
      console.log(data);
    });
    }

      addReturnStocks(stock: Return) {
      // if (this.isNewForm) {
        this.returnToSupplierServiceService.addReturnStocks(stock).subscribe(data => {
          console.log(data);
        });
        this.returnStocks.push(stock);
      }

}

interface Return {
        ReturnStockID: number;
        ReturnStockCode: string;
        ReturnCause: string;
        ReturnQty: number;
        Replacement: string;
        ReturnedToSupplier: string;
}
