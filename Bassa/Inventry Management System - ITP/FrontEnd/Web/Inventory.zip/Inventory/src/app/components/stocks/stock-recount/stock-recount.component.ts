import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-recount',
  templateUrl: './stock-recount.component.html',
  styleUrls: ['./stock-recount.component.css']
})
export class StockRecountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
