import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './../../../services/employee.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

	

	FirstName : string;
	LastName : string;
	Gender : string;
	DOB : string;
	NIC : string;

	Street: string;
	Town : string;
	City : string;
	Province : string;

	JobTitle : string;
	Email : string;
	Phone : string;
	Level : string;

	isUpdate:boolean = false;

	currentEmployee : employee;
	employeeId : number;

  constructor(
  	private employeeService:EmployeeService,
  	private route: ActivatedRoute) { }

  ngOnInit() {
  	this.route.params.subscribe(params => {
  		this.employeeId = params['id'];
      console.log(params['id']) //log the value of id
      if(params['id'] > 0){
      	this.isUpdate = true;
      	this.employeeService.getEmployeeById(params['id']).subscribe(data=>{
      		console.log(data);
      		this.currentEmployee = data;
      		this.FirstName = this.currentEmployee.FirstName;
      		this.LastName = this.currentEmployee.LastName;
      		this.NIC = this.currentEmployee.NIC;
      		this.Gender = this.currentEmployee.NIC;

      		this.JobTitle = this.currentEmployee.JobTitle;
      		this.Street = this.currentEmployee.Street;
      		this.Town = this.currentEmployee.Town;
      		this.City = this.currentEmployee.City;
      		this.Province = this.currentEmployee.Province;

      		this.Email = this.currentEmployee.Email;
      	});

      }
    });
  }

  onFormSubmit(){

  		const currentEmployee = {
  			FirstName:this.FirstName,
  			LastName : this.LastName,
  			NIC : this.NIC,
  			Street : this.Street,
  			Town : this.Town,
  			City : this.City,
  			Province : this.Province,
  			Email : this.Email,
  			JobTitle : this.JobTitle
  		}

  		if(this.isUpdate){
  			console.log(currentEmployee);
  			this.employeeService.updateEmployee(this.employeeId,currentEmployee).subscribe(data=>{
  				console.log(data);
  			});
  		}
  		else{

  			console.log(currentEmployee);
  			this.employeeService.addEmployee(currentEmployee).subscribe(data=>{
  				console.log(data);
  			});
  		}
  }

}

interface employee {
	EmployeeID: number;
    EmployeeName: string;
    JobTitle: string;
    Suspend: boolean;
    PersonID: number;
    FirstName: string;
    LastName: string;
    InitialName: string;
    Street: string;
    Town: string;
    City: string;
    Province: string;
    NIC: string;
    Email: string;
    Gender: number;
}