import { Component, OnInit } from '@angular/core';
import { CategoriesService} from './../../../services/categories.service';

@Component({
  selector: 'app-handle-category',
  templateUrl: './handle-category.component.html',
  styleUrls: ['./handle-category.component.css']
})
export class HandleCategoryComponent implements OnInit {

  addCategoryName : string;
  removeCategoryId : number;
  addSubCategoryName : string;
  addDescription : string;
  selectedCategoryId : number;
  selectedCategoryForSub : number;
  removeSubCategoryId : number;
  categories : category[];
  subCategories : subCategory[];

  constructor(
    private categoryService : CategoriesService
  ) { }

  ngOnInit() {
  	this.categoryService.getAllCategories().subscribe(data =>{
      this.categories = data;
    });
  }

  onaddCategory() {
    const category = {
      CategoryName: this.addCategoryName
    }
    this.categoryService.addCategories(category).subscribe(data =>{
      console.log(data);
    });
  }

  onremoveCategory() {
    this.categoryService.removeCategories(this.removeCategoryId).subscribe(data =>{
      console.log(data);
    });
  }

  onaddSubCategory() {
    const subCategory = {
      SubCategoryName: this.addSubCategoryName,
      Description : this.addDescription,
      CategoryId : this.selectedCategoryId
    }
    this.categoryService.addSubCategories(subCategory).subscribe(data =>{
      console.log(data);
    });
  }

  ongetSubCategory() {
    this.categoryService.getSubCategory(this.selectedCategoryForSub).subscribe(data =>{
      this.subCategories = data;
    });
  }

  onremoveSubCategory() {
    this.categoryService.removeSubCategories(this.removeSubCategoryId).subscribe(data =>{
      console.log(data);
    });
  }
}

interface category {
  CategoryId: number;
  CategoryName: string;
}

interface subCategory {
  SubCategoryId: number;
  SubCategoryName: string;
  Description: string;
  CategoryId: number;
}