import { Component, OnInit } from '@angular/core';
import { SectionsService } from './../../../services/sections.service';
import { ProductsService } from './../../../services/products.service';

@Component({
  selector: 'app-handle-products-section',
  templateUrl: './handle-products-section.component.html',
  styleUrls: ['./handle-products-section.component.css']
})
export class HandleProductsSectionComponent implements OnInit {

  selectedRackForSecAdd : number;
  selectedRackForSecUpdate : number;
  selectedRackForInsert : rack;
  selectedRackForModify : rack;
  addProductId : string;
  updateProductId : string; 
  removeProductId : string;
  sections : section[];
  racksAdd : rack[];
  racksUpdate : rack[];

  constructor(
    private sectionService : SectionsService,
    private productService : ProductsService
  ) { }

  ngOnInit() {
    this.sectionService.getAllSections().subscribe(data =>{
      this.sections = data;
    });
  }

  ongetRackInAdd() {
    this.sectionService.getRack(this.selectedRackForSecAdd).subscribe(data =>{
      this.racksAdd = data;
    });
  }

  onaddProductToRack() {
    this.productService.addProductsToRacks(this.selectedRackForInsert,this.addProductId).subscribe(data =>{
      console.log(data);
    });
  }

  ongetRackInUpdate() {
    this.sectionService.getRack(this.selectedRackForSecUpdate).subscribe(data =>{
      this.racksUpdate = data;
    });
  }

  onupdateProductToRack() {
    this.productService.updateProductInRack(this.selectedRackForModify,this.updateProductId).subscribe(data =>{
      console.log(data);
    });
  }

  onremoveProductInRack() {
    this.productService.removeProductInRack(this.removeProductId).subscribe(data =>{
      console.log(data);
    });
  }

}

interface section {
  SectionId: number;
  SectionName: string;
}

interface rack {
  RackId: number;
  RackName: string;
  SectionId: number;
}
