import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class SystemService {

	constructor(
		private http:Http 
		) { }

	getSystem(){
		return this.http.get('http://localhost:5556/api/system').map(res => res.json());
	}

	addSystem(system){
		return this.http.post('http://localhost:5556/api/system', system).map(res => res.json());
	}

	updateSystem(system){
		return this.http.put('http://localhost:5556/api/system/', system).map(res => res.json());
	}
}