import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promotion-schedule',
  templateUrl: './promotion-schedule.component.html',
  styleUrls: ['./promotion-schedule.component.css']
})
export class PromotionScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
